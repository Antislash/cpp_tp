#include <iostream>
#include <fstream>
#include <cstdlib>
#include <algorithm>
#include <unordered_map>
#include <vector>

int main()
{
	std::string user_word = ""; 

	std::cout << "Veuillez rentrer le mot que vous souhaitez rechercher" << std::endl ;
	std::cin >> user_word;

	std::string sort_word = user_word;
	std::sort(sort_word.begin(), sort_word.end());

	// Ouverture du fichier
  	std::ifstream ifs( "test.txt" );

  	std::string word_non_sorted;

  	std::unordered_map<std::string, std::vector<std::string>> words;

  	std::vector<std::string> new_word;

	// Ouverture correcte ?
	if(ifs.rdstate() == ifs.goodbit)
	{
		std::string line;
		
		while( std::getline(ifs, line) ) 
		{
			word_non_sorted = line;
			std::sort(line.begin(), line.end());
			if(words.find(line) != words.end())
			{
				words[line].push_back(word_non_sorted);				
			}
			else
			{
				new_word.push_back(word_non_sorted);
				words.emplace(line, new_word);
				new_word.clear();
			}
		} 
	}
	else
	{
		std::cerr << "Erreur de lectur du fichier " << "\n";
	}

	std::cout << "\nPour le mot " << user_word << " il y a la/les anagrammes suivante(s):" << std::endl;
	new_word = words[sort_word];
	for(unsigned int i = 0; i < words[sort_word].size(); i++)
	{
		std::cout << new_word[i] << std::endl;
	}

	return 0;
}