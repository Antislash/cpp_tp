#include <iostream>
#include "complex.hpp"
#include <complex.h>

int main(void){

	Complex <float>test1(2,3), test2, test3;


	std::cout << "Série de test" << std::endl;

	std::cout << "Voici l'imaginaire pure : " << img_pure << std::endl;

	std::cout << "Le premier complex vaut : " << test1 << std::endl;

	std::cout << "Veuillez saisir un deuxieme complex : " << std::endl;
	std::cin >> test2;
	std::cout << "Celui ci vaut " << test2 << std::endl;

	std::cout << "On affecte les valeurs du 1er complex à un 3éme complex" << std::endl;
	test3 = test1;
	std::cout << "Voici les valeurs du 3ème complex " << test3 << std::endl;
	std::cout << std::endl;

	std::cout << "On additionne le 1er et le 2eme complex dans le 3eme complex" << std::endl;
	test3 = test1 + test2;
	std::cout << "Les valeurs de cette addition donne " << test3 << std::endl;

	std::cout << "On soustrait le 1er et le 2eme complex dans le 3eme complex" << std::endl;
	test3 = test1 - test2;
	std::cout << "Les valeurs de cette soustraction donne " << test3 << std::endl;

	std::cout << "On mutliplie le 1er et le 2eme complex dans le 3eme complex" << std::endl;
	test3 = test1 * test2;
	std::cout << "Les valeurs de cette multiplication donne " << test3 << std::endl;

	std::cout << "On divise le 1er et le 2eme complex dans le 3eme complex" << std::endl;
	test3 = test1 / test2;
	std::cout << "Les valeurs de cette division donne " << test3 << std::endl;


	std::complex<float> test4(1,2);
	Complex<float> test5(1,2);

	std::cout << std::exp(test4) << " et " << exp(test5) << std::endl;


	return 0;
}