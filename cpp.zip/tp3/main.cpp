#include <iostream>
#include "rectangle.hpp"
#include "square.hpp"


int main(void){

	std::cout << "test";

	return 0;
}